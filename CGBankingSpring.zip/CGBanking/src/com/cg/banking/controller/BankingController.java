package com.cg.banking.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingController {
	@Autowired
	BankingServices bankingServices;
	public BankingServices getBankingServices() {
		return bankingServices;
	}
	public void setBankingServices(BankingServices bankingServices) {
		this.bankingServices = bankingServices;
	}
	@ModelAttribute("roleList")
	public List<String> roleList(){
		List<String> roleList=new ArrayList<>();
		roleList.add("admin");
		roleList.add("user");
		return roleList;
	}
	//----------------------------login page----------------------------------------
	@RequestMapping(value="/showLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model,@ModelAttribute(value="roleList") List<String> roleList) {
		roleList=roleList();
		model.addAttribute("login", new Customer());
		model.addAttribute("roleList",roleList);
		return "LoginPage";
	}

	@RequestMapping(value="validate.obj",method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="login")Customer customer,BindingResult result,
			Model model) {
		if(result.hasErrors())
			return "LoginPage";
		else {
			try {
				if(bankingServices.loginValidation(customer.getCustomerId(),customer.getPassword())!=null) {
					if(customer.getRole().equals("user")) {
						model.addAttribute("Customer",bankingServices.findOne(customer.getCustomerId()));
						return "TransactionPage";
					}
						

				}
				else
					model.addAttribute("failure", "your username or password are wrong");
			}  catch (CustomerNotFoundException e) {
				e.printStackTrace();
			}
			return "LoginPage";
		}
	}
	//--------------open Account---------------------------------------
	@RequestMapping(value="openAccountPage.obj",method=RequestMethod.GET)
	public String displayOpenAccount2(Model model) {
		model.addAttribute("Customer",new Customer());
		return "OpenAccount";
	}
	//----------------------------openAccount----------------------------------------------
	@RequestMapping(value="/openAccount",method=RequestMethod.POST)
	public String openAccount2(@ModelAttribute(value="Customer")Customer customer,Model model) {
		try {
			model.addAttribute("account",bankingServices.openAccount(new Customer(customer.getFirstName(), customer.getLastName(), customer.getEmailId(), 
					customer.getPancard(),customer.getPassword(),customer.getMobileNo(),customer.getAdharNo(), new Address(customer.getAddress().getCity(), customer.getAddress().getState(), 
							customer.getAddress().getCountry(), customer.getAddress().getPinCode())), 
					new Account(customer.getAccount().getAccountType(), customer.getAccount().getAccountBalance())));
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException e) {
			e.printStackTrace();
		}
		model.addAttribute("message", "account Opened");
		return "OpenAccount";
	}

	@RequestMapping(value="/displayDeposit",method=RequestMethod.POST)
	public String displayDepositAmountPage(Model model,@ModelAttribute(value="login")Account account) {
		return "DepositPage";
	}
	@RequestMapping(value="/DepositAmount",method=RequestMethod.POST)
	public String DepositAmount(Model model,@ModelAttribute(value="login")Account account,
			@RequestParam(value="depositAmount")float amount) {
		try {
			bankingServices.depositAmount(account.getAccountNo(), amount);
		} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		model.addAttribute("deposited", "amount deposited successfully");
		return "DepositPage";
	}
	@RequestMapping(value="/displayWithdraw",method=RequestMethod.POST)
	public String displayWithdrawAmountPage(Model model,@ModelAttribute(value="login")Account account) {
		return "WithdrawPage";
	}
	@RequestMapping(value="/WithdrawAmount",method=RequestMethod.POST)
	public String WithdrawAmount(Model model,@ModelAttribute(value="login")Account account,
			@RequestParam(value="withdrawAmount")float amount) {
		try {
			bankingServices.withdrawAmount(account.getAccountNo(), amount, account.getPinNumber());
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		model.addAttribute("withdraw", "amount withdrawl successfully");
		return "WithdrawPage";
	}
	@RequestMapping(value="/displayFundTransfer",method=RequestMethod.POST)
	public String displayFundTransferPage(Model model,@ModelAttribute(value="login")Account account) {
		return "FundTransferPage";
	}
	@RequestMapping(value="/FundTransfer",method=RequestMethod.POST)
	public String FundTransfer(Model model,@ModelAttribute(value="login")Account account,
			@RequestParam(value="TransferAmount")float amount,@RequestParam(value="accountNoTo")long accountNoTo) {
		try {
			bankingServices.fundTransfer(accountNoTo,account.getAccountNo(),amount, account.getPinNumber());
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		model.addAttribute("success", "amount Transfered successfully");
		return "FundTransferPage";
	}
}
