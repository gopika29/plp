package com.cg.banking.services;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class BankingServicesImpl implements BankingServices {
	AccountDAO accountDAO=new AccountDAOImpl();
	TransactionDAO transactionDAO=new TransactionDAOImpl();
	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(accountType, initBalance);
		account.setPinNumber((int) (Math.random()*12345));
		account.setStatus("active");
		if(accountType.equalsIgnoreCase("savings")||accountType.equalsIgnoreCase("current")) {
			if(initBalance<500)
				throw new InvalidAmountException("initial balance will be min 500");
		}
		else throw new InvalidAccountTypeException("Account type is invalid");
		accountDAO.save(account);
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws  BankingServicesDownException, AccountBlockedException, AccountNotFoundException {
		Account account=getAccountDetails(accountNo);
		if(account.getStatus().equalsIgnoreCase("active")) {
			account.setAccountBalance(account.getAccountBalance()+amount);
			transactionDAO.save(new Transaction(amount, "deposit",account));
		}
		accountDAO.update(account);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		if(account.getStatus().equalsIgnoreCase("active")) {
			if(pinNumber!=account.getPinNumber()) throw new InvalidPinNumberException("invalid pin");
			else if(account.getAccountBalance()<amount) throw new InsufficientAmountException("insufficient amount");
			else {
				account.setAccountBalance(account.getAccountBalance()-amount);
				transactionDAO.save(new Transaction(amount, "withdraw",account));
			}
		}
		accountDAO.update(account);
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account toAccount=getAccountDetails(accountNoTo);
		Account fromAccount=getAccountDetails(accountNoFrom);
		if(accountStatus(accountNoTo).equals("active")||accountStatus(accountNoFrom).equals("active")) {
			if(pinNumber!=fromAccount.getPinNumber())throw new InvalidPinNumberException("invalid pin");
			else if(fromAccount.getAccountBalance()<transferAmount)throw new InsufficientAmountException("insufficient amount");
			else {
				fromAccount.setAccountBalance(fromAccount.getAccountBalance()-transferAmount);
				toAccount.setAccountBalance(toAccount.getAccountBalance()+transferAmount);
				transactionDAO.save(new Transaction(transferAmount, "transferTo", toAccount));
				transactionDAO.save(new Transaction(transferAmount, "transferFrom", fromAccount));
			}
		}
		accountDAO.update(fromAccount);
		accountDAO.update(toAccount);
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accountDAO.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException("account details not found");
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		return accountDAO.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		Account account=getAccountDetails(accountNo);
		return transactionDAO.findAll(account.getAccountNo());
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		//transactionDAO.save(new Transaction("status_checking", account));
		if(account.getStatus().equalsIgnoreCase("blocked"))throw new AccountBlockedException("account blocked");
		return account.getStatus();
	}
	@Override
    public void pdfGenerator(long accountNo) throws FileNotFoundException, DocumentException, BankingServicesDownException, AccountNotFoundException {
        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Transactions.pdf"));
        document.open();
        document.add(new Paragraph("Transactions: "));
        com.itextpdf.text.List orderedList = new com.itextpdf.text.List(com.itextpdf.text.List.ORDERED);
        document.add(orderedList);
        for(Transaction t: new ArrayList<>(getAccountAllTransaction(accountNo))) {
            orderedList.add(t.toString());
        }
        document.add(orderedList);
        document.close();
        writer.close();
    }


}
