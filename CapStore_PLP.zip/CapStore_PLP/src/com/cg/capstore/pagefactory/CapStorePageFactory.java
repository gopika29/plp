package com.cg.capstore.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CapStorePageFactory {
	WebDriver driver;
	
	public CapStorePageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(linkText="EditProducts")
	@CacheLookup
	WebElement editProductsLink;
	@FindBy(linkText="MerchantPage")
	@CacheLookup
	WebElement merchantLink;
	@FindBy(linkText="AdminPage")
	@CacheLookup
	WebElement adminLink;
	public void setEditProductsLink() {
		this.editProductsLink.click();
	}
	public void setMerchantLink() {
		this.merchantLink.click();
	}
	public void setAdminLink() {
		this.adminLink.click();
	}
	
	
}
