package com.cg.capstore.daoservices;

public interface CategoryDao {

}
