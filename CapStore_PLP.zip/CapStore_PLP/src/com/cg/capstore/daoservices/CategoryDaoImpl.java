package com.cg.capstore.daoservices;

public class CategoryDaoImpl implements CategoryDao{

}
