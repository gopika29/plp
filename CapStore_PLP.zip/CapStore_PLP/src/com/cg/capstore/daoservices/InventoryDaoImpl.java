package com.cg.capstore.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Inventory;
@Repository("inventoryDao")
@Transactional
public class InventoryDaoImpl implements InventoryDao{
	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Inventory> getInventoryId(String merchantId) {
		return entityManager.createQuery("select i from Inventory i where i.MERCHANT_ID=:merchantId").setParameter("merchantId", merchantId).getResultList();
	}
	
}
