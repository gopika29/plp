package com.cg.capstore.daoservices;

import java.util.List;

import com.cg.capstore.bean.Inventory;

public interface InventoryDao {
	public List<Inventory> getInventoryId(String merchantId);
}
