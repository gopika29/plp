package com.cg.capstore.daoservices;

import com.cg.capstore.bean.Merchant;

public interface MerchantDao {
	public Merchant findOne(String merchantId);
}
