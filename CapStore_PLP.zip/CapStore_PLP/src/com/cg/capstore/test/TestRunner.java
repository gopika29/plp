package com.cg.capstore.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@CucumberOptions(features="features",glue="com.cg.capstore.stepdefinition")
@RunWith(Cucumber.class)
public class TestRunner {

}
