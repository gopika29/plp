package com.cg.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.capstore.bean.Merchant;
import com.cg.capstore.services.CapstoreServices;

@Controller
public class CapStoreController {
	@Autowired
	CapstoreServices capStoreServices;
	
	@RequestMapping(value="/HomePage",method=RequestMethod.GET)
	public String goToHomePage(Model model) {
		return "HomePage";
	}
	@RequestMapping(value="/MerchantPage",method=RequestMethod.GET)
	public String goToMerchantPage(Model model) {
		model.addAttribute("Merchant", new Merchant());
		return "GoToInventoryPage";
	}
	@RequestMapping(value="/EditItems",method=RequestMethod.POST)
	public String goToEditItemsPage(@ModelAttribute(value="Merchant")Merchant merchant,Model model) {
		model.addAttribute("welcome",capStoreServices.findOne(merchant.getMerchant_id()));
		return "MerchantInventory";
	}
	@RequestMapping(value="/AdminPage",method=RequestMethod.GET)
	public String goToAdminPage(Model model) {
		return "AdminPage";
	}
}
