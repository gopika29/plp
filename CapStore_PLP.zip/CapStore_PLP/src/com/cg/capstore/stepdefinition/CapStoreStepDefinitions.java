package com.cg.capstore.stepdefinition;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.cg.capstore.pagefactory.CapStorePageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CapStoreStepDefinitions {
	private WebDriver driver;
	private CapStorePageFactory capStorePageFactory;
	private String path="http://localhost:8082/CapStore_PLP/";
	@Before
	public void openBrowser() {
		String driverPath = "D:\\gankani_GopaKumari_Ankani\\BDD\\Selenium\\chromedriver_win32\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
	}
	//home Page step Defintions
	@Given("^home page has launched$")
	public void home_page_has_launched() throws Throwable {
		capStorePageFactory=new CapStorePageFactory(driver);
		driver.get(path);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^Merchant clicks on merchant page$")
	public void merchant_clicks_on_merchant_page() throws Throwable {
		Thread.sleep(1000);
	   capStorePageFactory.setMerchantLink();Thread.sleep(1000);
	}

	@Then("^Merchant will redirect to merchant page$")
	public void merchant_will_redirect_to_merchant_page() throws Throwable {
	    assertEquals(driver.getCurrentUrl(), path+"MerchantPage.obj");
	}
	@When("^Admin clicks on admin page$")
	public void admin_clicks_on_admin_page() throws Throwable {
		Thread.sleep(1000);
	    capStorePageFactory.setAdminLink();Thread.sleep(1000);
	}

	@Then("^Admin will redirect to admin page$")
	public void admin_will_redirect_to_admin_page() throws Throwable {
	   assertEquals(driver.getCurrentUrl(), path+"AdminPage.obj");
	}
	//Merchant Page stepDefinitions
	@Given("^Merchant is on merchant page$")
	public void merchant_is_on_merchant_page() throws Throwable {
		capStorePageFactory=new CapStorePageFactory(driver);
		driver.get(path+"MerchantPage.obj");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Then("^will be redirect to Edit Items Page$")
	public void will_be_redirect_to_Edit_Items_Page() throws Throwable {
	  assertEquals(driver.getCurrentUrl(), path+"EditItems.obj");
	}


	
	//Admin Page
	@Given("^admin is on admin page$")
	public void admin_is_on_admin_page() throws Throwable {
		capStorePageFactory=new CapStorePageFactory(driver);
		driver.get(path+"AdminPage.obj");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^clicks on edit products link$")
	public void clicks_on_edit_products_link() throws Throwable {
		 Thread.sleep(1000);
		 capStorePageFactory.setEditProductsLink(); Thread.sleep(1000);
	}

	
	@After
	public void closeBrowser() {
		driver.close();
	}
}
