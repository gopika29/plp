package com.cg.capstore.services;

import com.cg.capstore.bean.Merchant;

public interface CapstoreServices {
	public Merchant findOne(String merchantId);
}
