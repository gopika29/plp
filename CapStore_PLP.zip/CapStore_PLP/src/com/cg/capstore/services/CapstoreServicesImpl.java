package com.cg.capstore.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Merchant;
import com.cg.capstore.daoservices.InventoryDao;
import com.cg.capstore.daoservices.MerchantDao;
@Service
public class CapstoreServicesImpl implements CapstoreServices{
	@Autowired
	MerchantDao merchantDao;
	@Autowired
	InventoryDao inventoryDao;
	
	public MerchantDao getMerchantDao() {
		return merchantDao;
	}

	public void setMerchantDao(MerchantDao merchantDao) {
		this.merchantDao = merchantDao;
	}

	@Override
	public Merchant findOne(String merchantId) {
		System.out.println(inventoryDao.getInventoryId(merchantId));
		return merchantDao.findOne(merchantId);
	}

}
