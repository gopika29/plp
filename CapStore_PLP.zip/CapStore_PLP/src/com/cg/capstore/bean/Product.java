package com.cg.capstore.bean;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="CapStore_Product")
public class Product {
	@Id
	private String product_id;
	private String product_name;
	private String description;
	private double price;
	private int sold_quantity;
	private int avail_stock;
	private float discount;
	private int no_of_views;

	
	@ManyToMany
	@JoinColumn(name="merchantId",referencedColumnName="merchant_Id")
	private List<Merchant> merchant;
	
	@ManyToOne
	@JoinColumn(name="inventoryId")
	private Inventory inventory;
	
	@ManyToOne
	@JoinColumn(name="categoryId")
	private Category category;
	public Product() {
	}
	
	

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	

	

	public int getSold_quantity() {
		return sold_quantity;
	}

	public void setSold_quantity(int sold_quantity) {
		this.sold_quantity = sold_quantity;
	}

	public int getAvail_stock() {
		return avail_stock;
	}

	public void setAvail_stock(int avail_stock) {
		this.avail_stock = avail_stock;
	}

	public float getDiscount() {
		return discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public int getNo_of_views() {
		return no_of_views;
	}

	public void setNo_of_views(int no_of_views) {
		this.no_of_views = no_of_views;
	}

	

	public List<Merchant> getMerchant() {
		return merchant;
	}

	public void setMerchant(List<Merchant> merchant) {
		this.merchant = merchant;
	}

	public Inventory getInventory() {
		return inventory;
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	
}