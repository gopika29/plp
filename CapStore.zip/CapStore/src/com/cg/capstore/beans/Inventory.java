package com.cg.capstore.beans;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CapStore_Inventory")
public class Inventory {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int inventory_id;

	@OneToMany(mappedBy="inventory",cascade=CascadeType.ALL)
	private List<Product> products;

	@OneToMany(mappedBy="inventory",cascade=CascadeType.ALL)
	private List<Category> category;
	
	@OneToOne
	@JoinColumn(name = "merchantid",referencedColumnName="merchant_id")
	private Merchant merchant;

	public Inventory() {
	}

	

	public int getInventory_id() {
		return inventory_id;
	}

	public void setInventory_id(int inventory_id) {
		this.inventory_id = inventory_id;
	}

	
	public List<Product> getProducts() {
		return products;
	}



	public void setProducts(List<Product> products) {
		this.products = products;
	}



	public List<Category> getCategory() {
		return category;
	}



	public void setCategory(List<Category> category) {
		this.category = category;
	}



	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	

	


	@Override
	public String toString() {
		return "Inventory [inventory_id=" + inventory_id + "]";
	}



	


	

	
}