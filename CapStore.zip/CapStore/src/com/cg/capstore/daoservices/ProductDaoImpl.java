package com.cg.capstore.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.beans.Product;

@Repository
@Transactional
public class ProductDaoImpl implements ProductDao{
	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public List<Product> findAllProductsBasedOnInventory(int inventoryId) {
		return entityManager.
				createQuery("select p from Product p where inventoryId="+inventoryId).getResultList();
	}

	@Override
	public boolean removeProduct(String productId) {
		Product product=entityManager.find(Product.class, productId);
		System.out.println(product);
		entityManager.remove(product);
		entityManager.flush();
		return true;
	}

	@Override
	public Product findOne(String productId) {
		return entityManager.find(Product.class, productId);
	}

	@Override
	public boolean updateProduct(Product product) {
		entityManager.merge(entityManager.find(Product.class, product.getProduct_id()));
		entityManager.flush();
		return true;
	}
	
}
