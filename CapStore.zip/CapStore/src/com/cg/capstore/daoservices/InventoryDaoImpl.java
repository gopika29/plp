package com.cg.capstore.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.beans.Inventory;
@Repository("inventoryDao")
@Transactional
public class InventoryDaoImpl implements InventoryDao{
	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Inventory> getInventoryId() {
		return entityManager.createQuery("from Inventory i").getResultList();
	}
	
}
